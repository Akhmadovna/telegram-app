package frontend;

import backend.controller.UserController;
import backend.controller.UserControllerImpl;
import backend.model.User;

import java.util.Scanner;

public class FrontUI {

    static Scanner scanner = new Scanner(System.in);
    static UserController userController = new UserControllerImpl();

    public static void main(String[] args) {

        User user = new User("1", "1234", "rftgyu", "664");
        userController.add(user);

    }

}
