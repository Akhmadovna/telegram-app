package backend.model;

public class Message {
    private String id;
    private Chat chat;
    private String messageBody;
}
