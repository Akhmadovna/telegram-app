package backend.database;

import backend.model.Chat;
import backend.model.Message;
import backend.model.User;

import java.util.ArrayList;
import java.util.List;

public class DataBase {
    static List<User> userList = new ArrayList<>();
    static List<Chat> chatList = new ArrayList<>();
    static List<Message> messageList = new ArrayList<>();
}
