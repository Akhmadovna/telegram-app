package backend.payload;

public record UserRecord(String id, String name, String username) {
}
