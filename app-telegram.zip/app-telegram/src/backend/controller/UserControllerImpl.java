package backend.controller;

import backend.model.User;
import backend.payload.UserRecord;

public class UserControllerImpl implements UserController{
    @Override
    public UserRecord add(User user) {
        return null;
    }
}
