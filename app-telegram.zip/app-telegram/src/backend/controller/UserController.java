package backend.controller;

import backend.model.User;
import backend.payload.UserRecord;

public interface UserController {
    UserRecord add(User user);
}
